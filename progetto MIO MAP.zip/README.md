# Breach Protocol — Progetto MAP

## Storia

Sei un analista IT che lavora fino a tardi per completare un audit di sicurezza.
Alle 22:47 il sistema rileva un attacco ransomware in corso sulla rete
aziendale. Il protocollo di emergenza attiva il lockdown perimetrale: porte
elettroniche bloccate e rete interna isolata. Gli intrusi hanno anche
sabotato il quadro elettrico generale, causando un blackout parziale in
alcune zone dell'edificio.

Obiettivo del giocatore: muoversi tra le stanze accessibili, raccogliere
indizi fisici, ripristinare il quadro elettrico e il sistema badge, e uscire
prima che il ransomware finisca di cifrare i dati aziendali.

Vincolo di coerenza narrativa: nessuna scorciatoia che ignori la fisica
del blackout. Dove manca corrente, niente elettronica funzionante; serve
una fonte di luce a batteria o un percorso alternativo via dispositivi su
linea elettrica separata.

## Mappa delle stanze ed enigmi

| # | Stanza | Stato corrente | Enigma | Classe |
|---|--------|-----------------|--------|--------|
| 1 | Open space uffici | Luci di emergenza | Codice ricavato da log nel DB | `EnigmaDatabase` |
| 2 | Sala server | Blackout reale | Lettura al buio con torcia | `EnigmaBuio` |
| 3 | Ufficio tecnico IT | Corrente attiva | Sblocco tablet con PIN | `EnigmaTablet` |
| 4 | Locale quadri elettrici | Da ripristinare | Sequenza interruttori | `EnigmaFisico` |
| 5 | Reception (dopo ripristino) | Corrente ripristinata | Portale interno (REST) | da implementare |

## Architettura del codice

```
com.breachprotocol
├── engine
│   ├── GameEngine     -> stato globale, smista stanze ed eventi
│   ├── Stanza          -> oggetti, enigmi, uscite, illuminazione
│   ├── Giocatore        -> inventario
│   └── GameTimer        -> countdown ransomware su thread separato
├── enigmi
│   ├── Enigma (astratta)
│   ├── EnigmaCodice
│   ├── EnigmaDatabase
│   ├── EnigmaBuio
│   ├── EnigmaTablet
│   └── EnigmaFisico
├── observer
│   └── EventManager    -> pattern Observer via lambda/Consumer
├── persistence
│   ├── SaveManager      -> serializzazione su file
│   └── DatabaseManager  -> query JDBC per l'enigma 1
└── gui (da implementare)
    ├── MainFrame
    ├── RoomPanel
    └── InventoryPanel
```

Tutte le classi dello scheletro sono compilabili ma contengono dei `TODO`
nei punti dove va inserita la logica specifica della vostra ambientazione
(testi, codici, immagini).

## Catena degli indizi (riferimento rapido)

Vedi `narrativa/testi_stanze.md` per i testi completi. Riassunto codici:

| Enigma | Codice/soluzione | Dove viene usato |
|--------|-------------------|--------------------|
| 1 — log DB | `B-7741` | Sblocca porta sala server |
| 2 — rack al buio | `419` | Sblocca armadietto chiavi |
| 3 — PIN tablet | `1402` | Rivela sequenza interruttori `2-4-1-3` |
| 4 — interruttori | `[2,4,1,3]` | Ripristina corrente + sblocca reception |
| 5 — REST finale | `7741-419` | Disattiva il lockdown |

## Playtest eseguito

Ho ripercorso l'intera partita con un harness di test che usa le classi
reali del motore (niente display disponibile in questo ambiente per
testare la GUI a schermo, ma la logica sotto è identica). Sono emersi 4
problemi, tutti risolti:

| # | Problema | Stanza | Fix |
|---|----------|--------|-----|
| 1 | Nessun modo di raccogliere oggetti dalla GUI | Open space | `Stanza.aggiungiOggetto`/`rimuoviOggetto` + pulsanti dinamici "Raccogli: X" in `RoomPanel` |
| 2 | Enigma database richiedeva una query mai eseguibile dalla GUI | Open space | Pulsante "Interroga database" in `RoomPanel` quando l'enigma attivo è `EnigmaDatabase` |
| 3 | `EnigmaBuio` teneva un flag interno scollegato dall'inventario reale | Sala server | Riscritto per controllare l'inventario tramite una lambda (`Supplier<Boolean>`) passata dal chiamante |
| 4 | `EnigmaFisico` non si poteva risolvere dal campo testo generico | Locale quadri elettrici | Pulsanti numerati per interruttore in `RoomPanel` quando l'enigma attivo è `EnigmaFisico` |

Verificato con un secondo playtest che segue esattamente la sequenza di
click che farebbe un giocatore reale (raccogli torcia → interroga DB →
verifica → buio risolto senza flag manuali → interruttori cliccati in
sequenza): tutti i passaggi ora funzionano end-to-end.

## Roadmap aggiornata

- [x] Storia e mappa stanze/enigmi definite
- [x] Testi narrativi completi con catena di indizi coerente
- [x] Scheletro classi engine (GameEngine, Stanza, Giocatore, GameTimer)
- [x] Scheletro enigmi (5 tipi, uno per requisito tecnico)
- [x] Pattern Observer con lambda (EventManager)
- [x] Scheletro persistenza (SaveManager, DatabaseManager)
- [x] Schema e popolamento del database (`database/schema.sql`, `seed.sql`)
- [x] GUI Swing minima: MainFrame, RoomPanel, InventoryPanel
- [x] `Main.java`: cablaggio di tutte le stanze/enigmi/listener Observer
- [x] `pom.xml` Maven con dipendenza SQLite JDBC
- [x] Testi narrativi caricati da file esterno (`src/main/resources/narrativa`)
- [x] Inizializzazione automatica del DB al primo avvio (`DatabaseInitializer`)
- [x] Salva/Carica collegato alla GUI (menu "Partita"), testato con un ciclo salva→reset→carica
- [x] Stato del server REST incluso nel salvataggio (`LockdownServer.sbloccato`)
- [x] Illustrazioni di scena vettoriali (Graphics2D) per tutte le 5 stanze
- [ ] Test di gioco end-to-end con persone reali + bilanciamento timer (15 minuti è solo un default)
- [ ] Documentazione finale per la consegna

## Come avviare il progetto

```bash
mvn compile exec:java
```
(richiede una connessione internet la prima volta, per scaricare la
dipendenza `sqlite-jdbc` da Maven Central). Al primo avvio il database
viene creato e popolato automaticamente in `database/breachprotocol.db`
— non serve eseguire gli script SQL a mano.

## Decisioni di progetto prese finora

| Decisione | Scelta | Motivazione |
|-----------|--------|-------------|
| Build tool | Maven | standard nei corsi, supportato da Eclipse/IntelliJ senza configurazione |
| Database | SQLite | file locale, nessun server da installare |
| Sito REST | `HttpServer` del JDK | un solo endpoint, Spring Boot sarebbe overkill |
| Parsing JSON nel REST | regex manuale | payload banale (un solo campo); con payload più ricchi conviene Gson/Jackson |
| Testi narrativi | file `.txt` separati dal codice | più facile da modificare senza toccare le classi Java |
| Inizializzazione DB | automatica al primo avvio | evita di dover eseguire script SQL a mano prima di ogni demo/consegna |
| Formato del salvataggio | solo "stato" (non gli oggetti Stanza/Enigma) | permette di ricaricare una partita senza dover ricostruire la GUI già aperta |
| Asset grafici | illustrazioni vettoriali in Graphics2D, niente immagini esterne | zero dipendenze/licenze da gestire, facile da modificare, dimostra anche custom painting in Swing |

## Limiti noti (da tenere a mente)

- Il countdown del `GameTimer`, una volta fermato (es. a fine partita),
  non riparte da solo dopo un caricamento: andrebbe gestito un riavvio
  esplicito del thread se si vuole supportare "carica e continua a giocare"
  con un timer ancora attivo.

## Prossimi passi consigliati

1. **Test di gioco end-to-end** con un compagno di squadra che gioca dall'inizio
   alla fine, per validare la difficoltà degli enigmi e i tempi del countdown.
2. **Documentazione finale** per la consegna (il programma del corso di
   solito richiede una relazione a parte: questo README + `narrativa/testi_stanze.md`
   coprono già buona parte dei contenuti necessari).
3. Se volete, possiamo sostituire le illustrazioni Graphics2D con vere
   immagini in un secondo momento, senza toccare la logica di gioco.
